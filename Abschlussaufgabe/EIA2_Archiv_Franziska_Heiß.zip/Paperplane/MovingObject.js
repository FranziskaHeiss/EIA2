var AbschlussAufgabe;
(function (AbschlussAufgabe) {
    class MovingObject {
        constructor() {
            //
        }
        checkPosition() {
            //    
        }
        move() {
            //
        }
        draw() {
            //
        }
    }
    AbschlussAufgabe.MovingObject = MovingObject; //class MovingObjects zu
})(AbschlussAufgabe || (AbschlussAufgabe = {})); //namepsace
//# sourceMappingURL=MovingObject.js.map