namespace AbschlussAufgabe {
    export class MovingObject {
        x: number;
        y: number;

        constructor() {
            //
        }

        checkPosition(): void {
            //    
        }

        move(): void {
            //
        }

        draw(): void {
            //
        }
    } //class MovingObjects zu
}//namepsace